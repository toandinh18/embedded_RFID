<?php $__env->startSection('main'); ?>

<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-0.5">Edit the member infor</h1>
        <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>">
            <?php echo method_field('PATCH'); ?> 
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="Name">Name:</label>
                <input type="text" class="form-control" name="Name" value=<?php echo e($user->Name); ?> />
            </div>

            <div class="form-group">
                <label for="Phone_number"> Phone :</label>
                <input type="text" class="form-control" name="Phone_number" value=<?php echo e($user->Phone_number); ?> />
            </div>
            <div class="form-group">
                <label for="Authorized"> Authorized :</label>
                <input type="text" class="form-control" name="Authorized" value=<?php echo e($user->Authorized); ?> />
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\web_embedded\embedded\resources\views/users/edit.blade.php ENDPATH**/ ?>